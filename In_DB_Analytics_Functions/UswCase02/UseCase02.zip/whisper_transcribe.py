#!/usr/bin/python
"""
whisper_transcribe.py

A small utility script for decoding base64-encoded WAV audio, converting it to
a mono float32 waveform, and transcribing it using the Whisper Tiny model.
The script reads tab-separated rows from standard input, prints each filename,
and can be imported for programmatic transcription through `transcribe_wav_b64`.

Model loading falls back to the HuggingFace hub if the local model directory
is not found.

All error conditions terminate the program using `sys.exit(...)` with a
descriptive message.
"""


import sys
import os
import base64
import io
import wave
import numpy as np
import torch
from transformers import WhisperProcessor, WhisperForConditionalGeneration


from transformers import (
    WhisperFeatureExtractor,
    WhisperTokenizer,
    WhisperForConditionalGeneration,
    PreTrainedTokenizerFast
)
import json

# --- keep it single-threaded / "safe-ish" ---
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"
# Optional but helpful: put HF caches under ./models
os.environ.setdefault("TRANSFORMERS_CACHE", os.path.abspath("./models"))
os.environ.setdefault("HF_HOME",             os.path.abspath("./models"))

try:
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
except Exception:
    pass

WHISPER_SR = 16000  # Whisper models expect 16kHz audio

column_names = [
    'path',
    'filename',
    'samplerate',
    'channels',
    'sampwidth_bytes',
    'n_frames',
    'duration_sec',
    'data_b64'
]

DELIMITER = '\t'
DEBUG = False

try:
    directory = str(sys.argv[1])
except IndexError:
    sys.exit("error the directory path argument is missing")

def _pcm_to_float32(pcm: np.ndarray, sampwidth: int) -> np.ndarray:
    if sampwidth == 1:
        return (pcm.astype(np.float32) - 128.0) / 128.0
    elif sampwidth == 2:
        return (pcm.astype(np.float32) / 32768.0).clip(-1.0, 1.0)
    elif sampwidth == 3:
        b = pcm.view(np.uint8).reshape(-1, 3)
        sign = (b[:, 2] & 0x80) != 0
        pad = np.where(sign, 0xFF, 0x00).astype(np.uint8)
        b4 = np.column_stack([b, pad])
        i32 = b4.view(np.int32).ravel()
        return (i32.astype(np.float32) / 8388608.0).clip(-1.0, 1.0)
    elif sampwidth == 4:
        return (pcm.astype(np.float32) / 2147483648.0).clip(-1.0, 1.0)
    else:
        sys.exit(f"Unsupported sample width: {sampwidth} bytes")

def _read_wav_from_base64(b64_str: str):
    try:
        payload = base64.b64decode(b64_str.encode("ascii"), validate=False)
    except Exception as e:
        msg = str(e).split("\n")[0]
        sys.exit(f"Invalid base64 audio: {msg}")

    try:
        with wave.open(io.BytesIO(payload), "rb") as wf:
            n_channels = wf.getnchannels()
            sampwidth  = wf.getsampwidth()
            framerate  = wf.getframerate()
            n_frames   = wf.getnframes()
            raw = wf.readframes(n_frames)
    except Exception as e:
        msg = str(e).split("\n")[0]
        sys.exit(f"Error reading WAV header/data: {msg}")

    if sampwidth == 1:
        dtype = np.uint8
    elif sampwidth == 2:
        dtype = np.int16
    elif sampwidth == 3:
        dtype = np.uint8
    elif sampwidth == 4:
        dtype = np.int32
    else:
        sys.exit(f"Unsupported sample width: {sampwidth}")

    try:
        if sampwidth == 3:
            pcm = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 3)
            sign = (pcm[:, 2] & 0x80) != 0
            pad = np.where(sign, 0xFF, 0x00).astype(np.uint8)
            b4 = np.column_stack([pcm, pad]).view(np.int32).ravel()
            floats = (b4.astype(np.float32) / 8388608.0).clip(-1.0, 1.0)
        else:
            pcm = np.frombuffer(raw, dtype=dtype)
            floats = _pcm_to_float32(pcm, sampwidth)
    except Exception as e:
        msg = str(e).split("\n")[0]
        sys.exit(f"Error converting PCM to float: {msg}")

    if n_channels > 1:
        try:
            floats = floats.reshape(-1, n_channels).mean(axis=1)
        except Exception:
            pass

    return floats.astype(np.float32), int(framerate)


# --------------------------------------------

def load_whisper_local_425(local_dir: str):
    """
    Load Whisper (tiny) from a local directory with transformers==4.25.1.
    Expects files like: config.json, tokenizer.json, tokenizer_config.json,
    preprocessor_config.json, pytorch_model.bin (prefer this one).
    """
    if not os.path.isdir(local_dir):
        raise SystemExit(f"Error: directory does not exist: {local_dir}")

    # 1) Feature extractor (log-mel pipeline)
    try:
        feature_extractor = WhisperFeatureExtractor.from_pretrained(
            local_dir, local_files_only=True
        )
        if DEBUG: print("Feature extractor loaded successfully.")
    except Exception as e:
        sys.exit(
            f"Error loading feature extractor from {local_dir}: {str(e).splitlines()[0]}"
        )
        feature_extractor = None

    # 2) Tokenizer (use slow tokenizer to avoid WhisperTokenizerFast issues)
    # 2) Tokenizer (load fast tokenizer file explicitly)
    tok_file = os.path.join(local_dir, "tokenizer.json")
    if not os.path.isfile(tok_file):
        sys.exit(f"Error: tokenizer.json not found at {tok_file}")

    try:
        tokenizer = PreTrainedTokenizerFast(tokenizer_file=tok_file)
        # Try to apply any special tokens from tokenizer_config.json
        tk_cfg_path = os.path.join(local_dir, "tokenizer_config.json")
        if os.path.isfile(tk_cfg_path):
            with open(tk_cfg_path, "r", encoding="utf-8") as f:
                tk_cfg = json.load(f)
            # Set BOS/EOS/PAD if not already present
            for k in ("bos_token", "eos_token", "pad_token"):
                val = tk_cfg.get(k)
                if val and getattr(tokenizer, k) is None:
                    setattr(tokenizer, k, val)
        # Ensure we have a pad token (Whisper commonly pads with EOS)
        if tokenizer.pad_token is None and tokenizer.eos_token is not None:
            tokenizer.pad_token = tokenizer.eos_token
        if DEBUG: print("Tokenizer loaded successfully.")
    except Exception as e:
        sys.exit(f"Error loading tokenizer from {local_dir}: {str(e).splitlines()[0]}")


    # 3) Model (force bin to avoid safetensors edge cases on old versions)
    if True:
        try:
            model = WhisperForConditionalGeneration.from_pretrained(
                local_dir,
                local_files_only=True
            )
            model = model.to("cpu").eval()
            if DEBUG: print("Model loaded successfully.")
        except Exception as e:
            sys.exit(
                f"Error loading model from {local_dir}: {str(e).splitlines()[0]}"
            )
            model = None
    else:
        model = None

    return feature_extractor, tokenizer, model

def transcribe_waveform(
    audio_f32, sr, feature_extractor, tokenizer, model,
    language="en", task="transcribe", max_new_tokens=128
):
    """
    audio_f32: 1-D float32 mono waveform in [-1, 1]
    sr:        sample rate (int)
    """
    # 1) build log-mel features
    feats = feature_extractor(
        audio_f32, sampling_rate=sr, return_tensors="pt"
    ).input_features  # shape: (1, 80, T)

    # 2) set decoder prompt ids for Whisper on 4.25.1 (important!)
    forced_ids = None
    if hasattr(tokenizer, "get_decoder_prompt_ids"):
        try:
            forced_ids = tokenizer.get_decoder_prompt_ids(
                language=language, task=task
            )
        except Exception:
            forced_ids = None

    # 3) generate ids
    with torch.no_grad():
        generated_ids = model.generate(
            feats,
            forced_decoder_ids=forced_ids,
            max_new_tokens=max_new_tokens
        )

    # 4) decode to text
    text = tokenizer.batch_decode(
        generated_ids, skip_special_tokens=True
    )[0]
    return text.strip()


def resample_to_16k(audio: np.ndarray, sr: int) -> np.ndarray:
    """
    Linear interpolation NumPy resampler. No external deps.
    """
    if sr == WHISPER_SR:
        return audio.astype(np.float32)

    if len(audio) == 0:
        return audio.astype(np.float32)

    # new length
    new_len = int(round(len(audio) * (WHISPER_SR / float(sr))))
    if new_len <= 1:
        return audio.astype(np.float32)

    # interpolation
    src_x = np.arange(len(audio), dtype=np.float64)
    dst_x = np.linspace(0, len(audio) - 1, new_len, dtype=np.float64)
    out = np.interp(dst_x, src_x, audio.astype(np.float64))
    return out.astype(np.float32), WHISPER_SR


def remove_long_silence(
    audio: np.ndarray,
    sr: int,
    min_silence_sec: float = 0.5,   # only remove silence >= this duration
    threshold_db: float = -40.0,    # frames below this dBFS are "silent"
    frame_ms: float = 20.0,         # analysis window
    hop_ms: float = 10.0,           # hop between windows
    keep_silence_sec: float = 0.05  # leave this much audio at each side of a cut
) -> np.ndarray:
    """
    Remove stretches of silence longer than `min_silence_sec` from a mono float32 waveform.

    Parameters
    ----------
    audio : np.ndarray
        Mono float32 waveform in range roughly [-1, 1].
    sr : int
        Sample rate (e.g., 16000).
    min_silence_sec : float
        Minimum continuous silence duration to be removed.
    threshold_db : float
        Frame-level threshold in dBFS; below this is considered silence.
    frame_ms : float
        Frame length for RMS computation, in milliseconds.
    hop_ms : float
        Hop size between successive frames, in milliseconds.
    keep_silence_sec : float
        Amount of context to keep at both ends of each removed region.

    Returns
    -------
    np.ndarray
        The waveform with long silence removed.
    """
    if audio.ndim != 1:
        # ensure mono
        audio = np.mean(audio, axis=-1)

    N = len(audio)
    if N == 0:
        return audio

    # Analysis parameters
    frame_len = max(1, int(round(frame_ms * sr / 1000.0)))
    hop_len   = max(1, int(round(hop_ms   * sr / 1000.0)))
    n_frames  = 1 + max(0, (N - frame_len) // hop_len)

    # Compute frame RMS -> dBFS
    eps = 1e-12
    rms = np.empty(n_frames, dtype=np.float64)
    for i in range(n_frames):
        start = i * hop_len
        end   = start + frame_len
        x = audio[start:end]
        # pad last frame if needed
        if end > N:
            x = np.pad(x, (0, end - N))
        rms[i] = np.sqrt(np.mean(x.astype(np.float64) ** 2) + eps)

    db = 20.0 * np.log10(rms + eps)  # 0 dBFS ~ full-scale 1.0

    # Boolean mask of silent frames
    silent = db < threshold_db

    # Find contiguous runs of silent frames
    # We’ll remove only those whose duration >= min_silence_sec
    runs: List[Tuple[int, int]] = []  # (start_frame, end_frame_inclusive)
    if n_frames > 0:
        diff = np.diff(silent.astype(np.int8))
        starts = np.where(diff == 1)[0] + 1
        ends   = np.where(diff == -1)[0]
        # Handle edges
        if silent[0]:
            starts = np.r_[0, starts]
        if silent[-1]:
            ends = np.r_[ends, n_frames - 1]
        runs = list(zip(starts, ends))

    # Convert qualifying silent runs to sample ranges to remove
    min_silence_frames = int(np.ceil(min_silence_sec * 1000.0 / hop_ms))
    keep_pad = int(round(keep_silence_sec * sr))

    to_remove: List[Tuple[int, int]] = []
    for f0, f1 in runs:
        if (f1 - f0 + 1) >= min_silence_frames:
            # map frame run to sample indices
            s0 = f0 * hop_len
            s1 = min(N, f1 * hop_len + frame_len)
            # keep small context on both sides
            s0_cut = min(N, max(0, s0 + keep_pad))
            s1_cut = max(0, min(N, s1 - keep_pad))
            if s1_cut > s0_cut:
                to_remove.append((s0_cut, s1_cut))

    if not to_remove:
        return audio  # nothing to remove

    # Build keep intervals as the complement of removal ranges
    keep_segments: List[Tuple[int, int]] = []
    cursor = 0
    for s0, s1 in to_remove:
        if cursor < s0:
            keep_segments.append((cursor, s0))
        cursor = s1
    if cursor < N:
        keep_segments.append((cursor, N))

    if not keep_segments:
        return np.zeros(0, dtype=audio.dtype)

    # Concatenate kept segments
    parts = [audio[a:b] for (a, b) in keep_segments if b > a]
    return np.concatenate(parts, axis=0)

if DEBUG: print(f"Loading model from directory: {directory}")
if DEBUG: print(f"Contents: {os.listdir(directory)}")

feature_extractor, tokenizer, model = load_whisper_local_425(directory)


data_Tbl = []
while True:
    try:
        line = input()
        if line == '':
            break
        row = {c: x.replace(" ", "") for x, c in zip(line.split(DELIMITER), column_names)}

        STATUS        = 'successful'
        FILENAME      = row['filename']
        TRANSCRIPTION = ''

        try:
            audio_f32, sr = _read_wav_from_base64(row['data_b64'])
            if DEBUG: print('1 - Read audio:', row['filename'], 'sr=', sr, 'len=', len(audio_f32))
        except Exception as e:
            msg = str(e).splitlines()[0]
            if DEBUG: print(f"error: failed to read audio from '{row['filename']}': {msg}")
            STATUS = 'failed to read audio'
            continue

        if STATUS == 'successful':
            try:
                if sr != WHISPER_SR:
                    audio_f32, sr = resample_to_16k(audio_f32, sr)  
                    if DEBUG: print(f"2 - Read resampled audio:, filename : {row['filename']} n_frames : {row['n_frames']} channels : {row['channels']} sr: {row['samplerate']}")
            except Exception as e:
                msg = str(e).splitlines()[0]
                if DEBUG: print(f"error: failed to resample audio from '{row['filename']}': {msg} filename : {row['filename']} n_frames : {row['n_frames']} channels : {row['channels']} sr: {row['samplerate']}")
                STATUS = 'failed to resample audio'
                continue

        if STATUS == 'successful':
            try:
                audio_f32 = remove_long_silence(
                    audio_f32, sr,
                    min_silence_sec  = 0.5,
                    threshold_db     = -40.0,
                    frame_ms         = 20.0,
                    hop_ms           = 10.0,
                    keep_silence_sec = 0.05
                )
                if DEBUG: print(f"3 - Read silence removed audio:, filename : {row['filename']} n_frames : {row['n_frames']} channels : {row['channels']} sr: {row['samplerate']}")
            except Exception as e:
                msg = str(e).splitlines()[0]
                if DEBUG: print(f"error: failed to remove silence from '{row['filename']}': {msg} filename : {row['filename']} n_frames : {row['n_frames']} channels : {row['channels']} sr: {row['samplerate']}")
                STATUS = 'failed to remove silence from audio'
                continue

        if STATUS == 'successful': 
            try:

                TRANSCRIPTION = transcribe_waveform(
                    audio_f32, sr,
                    feature_extractor, tokenizer, model,
                    language="en", task="transcribe", max_new_tokens=128
                )
                if DEBUG: print(f"Transcribed: {row['filename']} Text: {transcription.replace(DELIMITER, ' ')}")
            except Exception as e:
                msg = str(e).splitlines()[0]
                if DEBUG: print(f"error: failed to transcribe audio from '{row['filename']}': {msg}")
                STATUS = 'failed to transcribe audio'
                continue

        if DEBUG == False:
            list_2_print = [FILENAME, STATUS, TRANSCRIPTION]
            print(DELIMITER.join(list_2_print))
    except EOFError:
        break

sys.exit(0)
