# ##################################################################
# 
# Copyright 2024 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
#  
# ################################################################## 

version = "20.00.00.01"
