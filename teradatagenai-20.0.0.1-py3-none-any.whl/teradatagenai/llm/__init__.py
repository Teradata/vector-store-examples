from .llm import TeradataAI
